package junitMilestone;

import java.util.List;
import java.util.ArrayList;

public class ContactService {
	
	private List<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	public void add(Contact newContact) {
		boolean isDuplicate = false;
		for (Contact contact: contacts) {
			if (contact.getContactID().equals(newContact.getContactID())) {
				isDuplicate = true;
				break;
			}
		}
		if (isDuplicate) {
			throw new IllegalArgumentException("Cannot add Contact ID already exists: " + newContact.getContactID());
		}
		contacts.add(newContact);
	}
	/**
	 * Get the contact with ID given
	 * Returns found contact if found, if not returns null value
	 * @param ContactID
	 * @return
	 */
	public Contact get(String ContactID) {
		//Search through list for ID
		Contact foundContact = null;
		
		for (Contact contact: contacts) {
			if (contact.getContactID().equals(ContactID)) {
				foundContact = contact;
				break;
			}
		}
		return foundContact;
	}
	//delete method
	public void delete(String contactID) {

	    Contact contactToDelete = null;

	    for (Contact contact : contacts) {
	        if (contact.getContactID().equals(contactID)) {
	            contactToDelete = contact;
	            break;
	        }
	    }

	    if (contactToDelete == null) {
	        throw new IllegalArgumentException("Contact does not exist");
	    }

	    contacts.remove(contactToDelete);
	}
	//update methods 
	public void updateFirstName(String contactID, String newFirstName) {

	    for (Contact contact : contacts) {

	        if (contact.getContactID().equals(contactID)) {

	            contact.setFirstName(newFirstName);
	            return;
	        }
	    }
	    throw new IllegalArgumentException("Contact does not exist");
	}
	
	public void updateLastName(String contactID, String newLastName) {

	    for (Contact contact : contacts) {

	        if (contact.getContactID().equals(contactID)) {

	            contact.setLastName(newLastName);
	            return;
	        }
	    }
	    throw new IllegalArgumentException("Contact does not exist");
	}
	
	public void updateNumber(String contactID, String newNumber) {

	    for (Contact contact : contacts) {

	        if (contact.getContactID().equals(contactID)) {

	            contact.setNumber(newNumber);
	            return;
	        }
	    }
	    throw new IllegalArgumentException("Contact does not exist");
	}
	
	public void updateAddress(String contactID, String newAddress) {

	    for (Contact contact : contacts) {

	        if (contact.getContactID().equals(contactID)) {

	            contact.setAddress(newAddress);
	            return;
	        }
	    }
	    throw new IllegalArgumentException("Contact does not exist");
	}
}