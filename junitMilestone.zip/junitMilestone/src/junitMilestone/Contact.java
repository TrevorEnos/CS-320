package junitMilestone;

public class Contact {
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	private String ContactID;
	
	public Contact(String firstName, String lastName, String Number, String Address, String ContactID) {
		if(firstName == null || firstName.length()>=10) {
			throw new IllegalArgumentException("Invalid First Name Please Try Another!");
		}
		if(lastName == null || lastName.length()>=10) {
			throw new IllegalArgumentException("Invalid Last Name Please Try Another!");
		}
		if(Number == null || Number.length()!=10) {
			throw new IllegalArgumentException("Invalid Number Please Try Another!");
		}
		if(Address == null || Address.length()>=30) {
			throw new IllegalArgumentException("Invalid Address Please Try Another!");
		}
		if(ContactID == null || ContactID.length()>=10) {
			throw new IllegalArgumentException("Invalid ID Please Try Another!");
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
		this.Address = Address;
		this.ContactID = ContactID;
	}
	//getters
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getNumber() {
		return Number;
	}
	public String getAddress() {
		return Address;
	}
	public String getContactID() {
		return ContactID;
	}
	//setters
	public void setFirstName(String firstName) {

	    if (firstName == null || firstName.length() >= 10) {
	        throw new IllegalArgumentException("Invalid first name");
	    }

	    this.firstName = firstName;
	}
	public void setLastName(String lastName) {

	    if (lastName == null || lastName.length() >= 10) {
	        throw new IllegalArgumentException();
	    }

	    this.lastName = lastName;
	}
	public void setNumber(String Number) {

	    if (Number == null || Number.length() != 10) {
	        throw new IllegalArgumentException();
	    }

	    this.Number = Number;
	}
	public void setAddress(String Address) {

	    if (Address == null || Address.length() >= 30) {
	        throw new IllegalArgumentException();
	    }

	    this.Address = Address;
	}
}