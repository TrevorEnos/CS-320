package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import junitMilestone.Contact;
import junitMilestone.ContactService;

public class ContactServiceTest {
	
	private ContactService service;
	
	@BeforeEach
	public void setup() {
		service = new ContactService();
	}
	//Add
	@Test
	public void testAdd_withNewElement_successfullyAdds() {
		//new Contact
		//add to service
		//check school was added
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		
		service.add(newContact);
		
		Assertions.assertEquals(service.get(newContact.getContactID()), newContact);
		
	}
	@Test
	public void testAdd_withDuplicateElement_throwsIllegalArgumentException() {
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		
		//check if exists
		//add to list
		service.add(newContact);
		Assertions.assertNotNull(service.get(newContact.getContactID()));
		
		//throw exception if exists
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.add(newContact));
	}
	
	//Delete
	@Test
	public void testDelete_existingContact_successfullyDeletes() {

	    // create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");

	    // add contact
	    service.add(newContact);

	    // verify exists
	    Assertions.assertNotNull(
	        service.get(newContact.getContactID())
	    );

	    // delete contact
	    service.delete(newContact.getContactID());

	    // verify deleted
	    Assertions.assertNull(
	        service.get(newContact.getContactID())
	    );
	}
	@Test
	public void testDelete_nonExistingContact_throwsException() {

	    Assertions.assertThrows(
	        IllegalArgumentException.class,
	        () -> service.delete("1")
	    );
	}
	//edit
	//first name
	@Test
	public void testUpdateFirstName_successfullyUpdates() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);
	    // update contact
	    service.updateFirstName(newContact.getContactID(), "Trevor");
	    // verify update
	    Assertions.assertEquals("Trevor", service.get(newContact.getContactID()).getFirstName());
	}
	@Test
	public void testUpdateFirstName_invalidID_throwsException() {

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1", "Trevor"));
	}
	@Test
	public void testUpdateFirstName_nameTooLong_throwsException() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateFirstName(newContact.getContactID(), "Billifords"));
	}
	//last name
	@Test
	public void testUpdateLastName_successfullyUpdates() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);
	    // update contact
	    service.updateLastName(newContact.getContactID(), "Enos");
	    // verify update
	    Assertions.assertEquals("Enos", service.get(newContact.getContactID()).getLastName());
	}
	@Test
	public void testUpdateLastName_invalidID_throwsException() {

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1", "Enos"));
	}
	@Test
	public void testUpdateLastName_nameTooLong_throwsException() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateLastName(newContact.getContactID(), "JonStewart"));
	}
	//Number
	@Test
	public void testUpdateNumber_successfullyUpdates() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);
	    // update contact
	    service.updateNumber(newContact.getContactID(), "1234567890");
	    // verify update
	    Assertions.assertEquals("1234567890", service.get(newContact.getContactID()).getNumber());
	}
	@Test
	public void testUpdateNumber_invalidID_throwsException() {

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateNumber("1", "1234567890"));
	}
	@Test
	public void testUpdateNumber_numberTooLong_throwsException() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateNumber(newContact.getContactID(), "12345678910"));
	}
	//Address
	@Test
	public void testUpdateAddress_successfullyUpdates() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);
	    // update contact
	    service.updateAddress(newContact.getContactID(), "123 Strawberry Dr");
	    // verify update
	    Assertions.assertEquals("123 Strawberry Dr", service.get(newContact.getContactID()).getAddress());
	}
	@Test
	public void testUpdateAddress_invalidID_throwsException() {

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1", "123 Strawberry Dr"));
	}
	@Test
	public void testUpdateAddress_nameTooLong_throwsException() {

		// create contact
		Contact newContact = new Contact("Bob", "Turn", "6343458795", "2356 Dimple Ln", "1");
		// add contact
	    service.add(newContact);

	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateAddress(newContact.getContactID(), "12345678910 This is a long road Dr"));
	}
}