package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import junitMilestone.Contact;

class ContactTest {
	
	@Test
	void testContactClass() {//test contact
		Contact contact = new Contact("Trevor", "Enos", "1234567890", "123 Strawberry Dr", "1");
		assertTrue(contact.getFirstName().equals("Trevor"));
		assertTrue(contact.getLastName().equals("Enos"));
		assertTrue(contact.getNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 Strawberry Dr"));
		assertTrue(contact.getContactID().equals("1"));
	}
	@Test
	void testContactNameToLong() {//test if too param of contact
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Billifords", "JonStewart", "1234567890", "12345678910 Thisisaroad Dr", "1");
		});
	}
	
}